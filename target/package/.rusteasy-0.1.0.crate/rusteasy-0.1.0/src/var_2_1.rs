pub fn var_2_1() {
    // Addition
    let sum = 5 + 10;

    // Subtraction
    let difference = 95.5 - 4.3;

    // Multiplication
    let product = 4 * 30;

    // Division
    let quotient = 56.7 / 32.2;
    let truncated = -5 / 3; // The result is -1

    // Remainder operation
    let remainder = 43 % 5;

    println!("Sum: {}", sum); // Print the sum
    println!("Subtraction: {}", difference); // Print the subtraction
    println!("Division : {}", quotient);
    println!("truncated : {}" , truncated);
    println!("remainder: {}", remainder);
}   
