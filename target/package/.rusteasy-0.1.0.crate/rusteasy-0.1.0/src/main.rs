// Assuming var_2_1 is defined in a module named var_2_1.rs or var_2_1/mod.rs
mod var_2_1;

fn main() {
    // Call the function from the other module
    var_2_1::var_2_1();
}
